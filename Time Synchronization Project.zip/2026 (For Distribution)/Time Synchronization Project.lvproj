﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="24008000">
	<Property Name="NI.LV.All.SaveVersion" Type="Str">24.0</Property>
	<Property Name="NI.LV.All.SourceOnly" Type="Bool">true</Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="server.app.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.control.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="server.tcp.enabled" Type="Bool">false</Property>
		<Property Name="server.tcp.port" Type="Int">0</Property>
		<Property Name="server.tcp.serviceName" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.tcp.serviceName.default" Type="Str">My Computer/VI Server</Property>
		<Property Name="server.vi.callsEnabled" Type="Bool">true</Property>
		<Property Name="server.vi.propertiesEnabled" Type="Bool">true</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="Utility" Type="Folder">
			<Item Name="Signal Selection.ctl" Type="VI" URL="../Signal Selection.ctl"/>
			<Item Name="TF - Enable and Disable Time References.vi" Type="VI" URL="../Utility/TF - Enable and Disable Time References.vi"/>
			<Item Name="TF Confirm Device time Utility.vi" Type="VI" URL="../Utility/TF Confirm Device time Utility.vi"/>
		</Item>
		<Item Name="0 - Voltage - Continuous Output.vi" Type="VI" URL="../0 - Voltage - Continuous Output.vi"/>
		<Item Name="1 - Simple Acquistiion Demo.vi" Type="VI" URL="../1 - Simple Acquistiion Demo.vi"/>
		<Item Name="2 - Multi-task Acquisition.vi" Type="VI" URL="../2 - Multi-task Acquisition.vi"/>
		<Item Name="3 - Multi-task Acquisition Plus FSCW.vi" Type="VI" URL="../3 - Multi-task Acquisition Plus FSCW.vi"/>
		<Item Name="4 - Multi-task Acquisition Plus FSCW (IO Device Timestamp).vi" Type="VI" URL="../4 - Multi-task Acquisition Plus FSCW (IO Device Timestamp).vi"/>
		<Item Name="5 - Multi-task Acquisition Plus FSCW (IO Device Timestamp) with PXI DAQ.vi" Type="VI" URL="../5 - Multi-task Acquisition Plus FSCW (IO Device Timestamp) with PXI DAQ.vi"/>
		<Item Name="normalize phase ange difference (SubVI).vi" Type="VI" URL="../normalize phase ange difference (SubVI).vi"/>
		<Item Name="Dependencies" Type="Dependencies"/>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
